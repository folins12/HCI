class Plant < ApplicationRecord
end

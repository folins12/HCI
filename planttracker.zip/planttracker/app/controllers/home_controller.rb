class HomeController < ApplicationController
  def index
    #codice
  end
end

class VivaiController < ApplicationController
  def index
    #codice
  end
end

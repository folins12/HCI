class PlantsController < ApplicationController
  def index
    #codice
  end
end

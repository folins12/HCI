class PagesController < ApplicationController
  def home
    #codice
  end
  def piante

  end
end
